import React, { useState, useEffect } from 'react';
import Countries from './components/Countries';
import axios from 'axios';

export default function App() {
  const [countries, setCountries] = useState([]);

  useEffect(() => {
    axios.get('https://restcountries.com/v2/all').then((response) => {
      console.log(response.data);
      setCountries(response.data);
    });
  }, []);

  return (
    <div>
      <p>
        find countries <input />
      </p>
      <Countries countries={countries} />
    </div>
  );
}
