import React, { useState, useEffect } from 'react';

const Countries = (props) => {
  return (
    <div>
      <p></p>
    </div>
  );
};

export default Countries;
